#pragma once

#include "cli_i.h"

void cli_commands_init(Cli* cli);