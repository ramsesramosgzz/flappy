#pragma once

#include "bt_i.h"

bool bt_load_key_storage(Bt* bt);

bool bt_save_key_storage(Bt* bt);

bool bt_delete_key_storage(Bt* bt);
