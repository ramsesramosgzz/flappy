#pragma once

#include "../archive_i.h"

#define DEFAULT_TAB_DIR InputKeyRight //default tab swith direction

static const char* tab_default_paths[] = {
    [ArchiveTabFavorites] = "/any/favorites",
    [ArchiveTabIButton] = "/any/ibutton",
    [ArchiveTabNFC] = "/any/nfc",
    [ArchiveTabSubGhz] = "/any/subghz",
    [ArchiveTabLFRFID] = "/any/lfrfid",
    [ArchiveTabInfrared] = "/any/infrared",
    [ArchiveTabBadUsb] = "/any/badusb",
    [ArchiveTabU2f] = "/app:u2f",
    [ArchiveTabBrowser] = "/any",
};

static const char* known_ext[] = {
    [ArchiveFileTypeIButton] = ".ibtn",
    [ArchiveFileTypeNFC] = ".nfc",
    [ArchiveFileTypeSubGhz] = ".sub",
    [ArchiveFileTypeLFRFID] = ".rfid",
    [ArchiveFileTypeInfrared] = ".ir",
    [ArchiveFileTypeBadUsb] = ".txt",
    [ArchiveFileTypeU2f] = "?",
    [ArchiveFileTypeFolder] = "?",
    [ArchiveFileTypeUnknown] = "*",
};

static const ArchiveFileTypeEnum known_type[] = {
    [ArchiveTabFavorites] = ArchiveFileTypeUnknown,
    [ArchiveTabIButton] = ArchiveFileTypeIButton,
    [ArchiveTabNFC] = ArchiveFileTypeNFC,
    [ArchiveTabSubGhz] = ArchiveFileTypeSubGhz,
    [ArchiveTabLFRFID] = ArchiveFileTypeLFRFID,
    [ArchiveTabInfrared] = ArchiveFileTypeInfrared,
    [ArchiveTabBadUsb] = ArchiveFileTypeBadUsb,
    [ArchiveTabU2f] = ArchiveFileTypeU2f,
    [ArchiveTabBrowser] = ArchiveFileTypeUnknown,
};

static inline const ArchiveFileTypeEnum archive_get_tab_filetype(ArchiveTabEnum tab) {
    return known_type[tab];
}

static inline const char* archive_get_tab_ext(ArchiveTabEnum tab) {
    return known_ext[archive_get_tab_filetype(tab)];
}

static inline const char* archive_get_default_path(ArchiveTabEnum tab) {
    return tab_default_paths[tab];
}

inline bool archive_is_known_app(ArchiveFileTypeEnum type) {
    return (type != ArchiveFileTypeFolder && type != ArchiveFileTypeUnknown);
}

void archive_update_offset(ArchiveBrowserView* browser);
void archive_update_focus(ArchiveBrowserView* browser, const char* target);

size_t archive_file_array_size(ArchiveBrowserView* browser);
void archive_file_array_rm_selected(ArchiveBrowserView* browser);
void archive_file_array_swap(ArchiveBrowserView* browser, int8_t d);
void archive_file_array_rm_all(ArchiveBrowserView* browser);

ArchiveFile_t* archive_get_current_file(ArchiveBrowserView* browser);
ArchiveFile_t* archive_get_file_at(ArchiveBrowserView* browser, size_t idx);
ArchiveTabEnum archive_get_tab(ArchiveBrowserView* browser);
uint8_t archive_get_depth(ArchiveBrowserView* browser);
const char* archive_get_path(ArchiveBrowserView* browser);
const char* archive_get_name(ArchiveBrowserView* browser);

void archive_add_app_item(ArchiveBrowserView* browser, const char* name);
void archive_add_file_item(ArchiveBrowserView* browser, FileInfo* file_info, const char* name);
void archive_show_file_menu(ArchiveBrowserView* browser, bool show);
void archive_favorites_move_mode(ArchiveBrowserView* browser, bool active);

void archive_switch_tab(ArchiveBrowserView* browser, InputKey key);
void archive_enter_dir(ArchiveBrowserView* browser, string_t name);
void archive_leave_dir(ArchiveBrowserView* browser);
